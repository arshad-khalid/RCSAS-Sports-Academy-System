package rslogin;
import java.io.*;
public class Rslogin 
{
    public static void main(String[] args) 
    {
        smenu sm = new smenu();
        sm.setVisible(true);
    }
    
}
