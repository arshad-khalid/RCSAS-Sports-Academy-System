//ARSHAD KHALID NAZIR (TP058473)

//Below code initiates the whole system
package assignment.rcsas;

public class RcsasSoftware {
    public static void main(String[] args) {
        UserTypeLogin utl = new UserTypeLogin();
        utl.setVisible(true);
        
    }
    
}
